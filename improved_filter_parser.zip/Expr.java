package com.example.filterparser.model;

public sealed interface Expr
        permits ComparisonExpr, InExpr, AndExpr, OrExpr { }

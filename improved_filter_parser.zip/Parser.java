package com.example.filterparser.parser;

import com.example.filterparser.model.*;

import java.util.ArrayList;
import java.util.List;

public class Parser {

    private final List<String> tokens;
    private int pos = 0;

    public Parser(List<String> tokens) {
        this.tokens = tokens;
    }

    private String peek() {
        return pos < tokens.size() ? tokens.get(pos) : null;
    }

    private String consume() {
        String tok = peek();
        if (tok == null) {
            throw new RuntimeException("Unexpected end of input");
        }
        pos++;
        return tok;
    }

    private String consume(String expected) {
        String tok = peek();
        if (tok == null || !tok.equalsIgnoreCase(expected)) {
            throw new RuntimeException("Expected '" + expected + "' but found '" + tok + "'");
        }
        pos++;
        return tok;
    }

    private boolean match(String keyword) {
        String tok = peek();
        if (tok != null && tok.equalsIgnoreCase(keyword)) {
            pos++;
            return true;
        }
        return false;
    }

    public Expr parse() {
        Expr expr = parseOrExpr();
        if (peek() != null) {
            throw new RuntimeException("Unexpected token at end: '" + peek() + "'");
        }
        return expr;
    }

    private Expr parseOrExpr() {
        Expr expr = parseAndExpr();
        while (match("OR")) {
            Expr right = parseAndExpr();
            expr = new OrExpr(expr, right);
        }
        return expr;
    }

    private Expr parseAndExpr() {
        Expr expr = parseFactor();
        while (match("AND")) {
            Expr right = parseFactor();
            expr = new AndExpr(expr, right);
        }
        return expr;
    }

    private Expr parseFactor() {
        String tok = peek();
        if ("(".equals(tok)) {
            consume("(");
            Expr inner = parseOrExpr();
            consume(")");
            return inner;
        }
        return parseComparisonOrIn();
    }

    private Expr parseComparisonOrIn() {

        String columnToken = consume();
        String column = normalizeColumn(columnToken);

        String op = consume();

        if ("=".equals(op)) {
            String value = consume();
            return new ComparisonExpr(column, value);
        }

        if ("IN".equalsIgnoreCase(op)) {
            consume("(");
            List<String> values = new ArrayList<>();

            while (true) {
                values.add(consume());
                String next = peek();
                if (",".equals(next)) {
                    consume(",");
                } else {
                    break;
                }
            }
            consume(")");
            return new InExpr(column, values);
        }

        throw new RuntimeException("Unknown operator: " + op);
    }

    private String normalizeColumn(String columnToken) {
        return columnToken.replace("[", "").replace("]", "");
    }
}

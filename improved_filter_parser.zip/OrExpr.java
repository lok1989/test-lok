package com.example.filterparser.model;

public record OrExpr(Expr left, Expr right) implements Expr { }

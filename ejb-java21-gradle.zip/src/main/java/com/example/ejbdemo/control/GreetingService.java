package com.example.ejbdemo.control;

import jakarta.ejb.Stateless;

@Stateless
public class GreetingService {

    public String greet(String name) {
        if (name == null || name.isBlank()) {
            name = "World";
        }
        return "Hello, " + name + " from EJB on Java 21 in Payara!";
    }
}

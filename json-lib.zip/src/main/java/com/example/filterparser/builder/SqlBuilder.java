package com.example.filterparser.builder;

import com.example.filterparser.model.*;

public class SqlBuilder {

    public static String toSql(Expr expr) {

        if (expr instanceof ComparisonExpr cmp) {
            return cmp.column() + " = " + cmp.value();
        }

        if (expr instanceof InExpr in) {
            String joined = String.join(",", in.values());
            return in.column() + " IN (" + joined + ")";
        }

        if (expr instanceof AndExpr and) {
            return "(" + toSql(and.left()) + " AND " + toSql(and.right()) + ")";
        }

        throw new RuntimeException("Unsupported expression type: " + expr);
    }
}

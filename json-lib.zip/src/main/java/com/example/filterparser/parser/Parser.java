package com.example.filterparser.parser;

import com.example.filterparser.model.*;

import java.util.ArrayList;
import java.util.List;

public class Parser {

    private final List<String> tokens;
    private int pos = 0;

    public Parser(List<String> tokens) {
        this.tokens = tokens;
    }

    private String peek() {
        return pos < tokens.size() ? tokens.get(pos) : null;
    }

    private String consume(String expected) {
        String tok = peek();
        if (tok == null || (expected != null && !tok.equalsIgnoreCase(expected))) {
            throw new RuntimeException("Expected '" + expected + "' but found '" + tok + "'");
        }
        pos++;
        return tok;
    }

    private String consume() {
        String tok = peek();
        pos++;
        return tok;
    }

    public Expr parse() {
        Expr expr = parsePrimary();

        while ("AND".equalsIgnoreCase(peek())) {
            consume("AND");
            expr = new AndExpr(expr, parsePrimary());
        }
        return expr;
    }

    private Expr parsePrimary() {

        String columnToken = consume(); 
        String column = columnToken.replace("[", "").replace("]", "");

        String op = consume();           

        if ("=".equals(op)) {
            String value = consume();    
            return new ComparisonExpr(column, value);
        }

        if ("IN".equalsIgnoreCase(op)) {
            consume("(");
            List<String> values = new ArrayList<>();

            while (true) {
                values.add(consume());  
                if (",".equals(peek())) {
                    consume(",");
                } else {
                    break;
                }
            }
            consume(")");
            return new InExpr(column, values);
        }

        throw new RuntimeException("Unknown operator: " + op);
    }
}

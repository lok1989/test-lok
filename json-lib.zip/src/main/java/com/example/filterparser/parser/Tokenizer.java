package com.example.filterparser.parser;

import java.util.*;
import java.util.regex.*;

public class Tokenizer {

    private static final Pattern TOKEN_PATTERN = Pattern.compile(
        "\\s*(\\[.*?])|" +
        "(IN)|" +
        "(AND)|" +
        "(=)|" +
        "('[^']*')|" +
        "(\\()|(\\))|" +
        "(,)"
    );

    public static List<String> tokenize(String input) {
        List<String> tokens = new ArrayList<>();
        Matcher m = TOKEN_PATTERN.matcher(input);

        while (m.find()) {
            for (int i = 1; i <= m.groupCount(); i++) {
                if (m.group(i) != null) {
                    tokens.add(m.group(i));
                    break;
                }
            }
        }
        return tokens;
    }
}

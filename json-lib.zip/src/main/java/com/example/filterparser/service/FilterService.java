package com.example.filterparser.service;

import com.example.filterparser.builder.SqlBuilder;
import com.example.filterparser.model.Expr;
import com.example.filterparser.parser.Parser;
import com.example.filterparser.parser.Tokenizer;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FilterService {

    public String convertToSql(String filterExpression) {

        List<String> tokens = Tokenizer.tokenize(filterExpression);

        Parser parser = new Parser(tokens);
        Expr ast = parser.parse();

        return SqlBuilder.toSql(ast);
    }
}

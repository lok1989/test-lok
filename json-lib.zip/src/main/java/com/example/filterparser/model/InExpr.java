package com.example.filterparser.model;

import java.util.List;

public record InExpr(String column, List<String> values) implements Expr { }

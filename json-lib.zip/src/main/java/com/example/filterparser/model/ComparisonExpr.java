package com.example.filterparser.model;

public record ComparisonExpr(String column, String value) implements Expr { }

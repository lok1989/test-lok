package com.example.filterparser.model;

public record AndExpr(Expr left, Expr right) implements Expr { }
